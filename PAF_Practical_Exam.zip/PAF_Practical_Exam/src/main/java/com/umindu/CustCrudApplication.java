package com.umindu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustCrudApplication.class, args);
	}

}
