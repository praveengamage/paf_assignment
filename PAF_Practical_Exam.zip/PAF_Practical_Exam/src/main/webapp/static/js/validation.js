//form validation

function validateForm() {
 var a = document.forms["welcomepage"]["firstname"].value;
 var b = document.forms["welcomepage"]["lastname"].value;
 var c = document.forms["welcomepage"]["email"].value;
 var d = document.forms["welcomepage"]["age"].value;
 var e = document.forms["welcomepage"]["password"].value;


 //	var emailPattern = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

 if (a == "" || b == "" || c == "" || d == "" || e == "") {
 alert("All the fields must be filled out!");
 return false;
 }


 //	if(!c.match(emailPattern)){
 //		alert("Invalid Email");
 //		return false;
 //	}

 //	if(!g.match(mobilePattern)){
 //		alert("Invalid Mobile");
 //		return false;
 //	}

 }

/*function emptyCheck(name, id) {
	var inputValue = document.getElementById(name);
	if (inputValue.value == "" || inputValue.value == null || inputValue.value == " ") {
		id.style.backgroundColor = "red";
	} else {
		id.style.backgroundColor = "";
	}
	
function validateForm() {
	var firstname = document.getElementById('firstname');
	var lastname = document.getElementById('lastname');
	var email = document.getElementById('email');
	var age = document.getElementById('age');
	var password = document.getElementById('password');
}*/
