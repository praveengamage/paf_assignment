// pattern validations
$(function() {

//	$("#cmp_website").focusout(function() {
//		chk_website();
//	});

	$("#email").focusout(function() {
		chk_email();
	});

	$("#password").focusout(function() {
		chk_password();
	});
	
//	$("#cmp_phnumber").focusout(function() {
//		chk_phnumber();
//	});


	function chk_email() {

		var email_pat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		var email_val = $("#email").val();

		if (email_pat.test(email_val) !== true) {

			alert("Invalid Email!!");
			return false;
		} else {
			return true;
		}
	}
	
	function check_password() {
		
		var password_length = $("#password").val().length;
		
		if(password_length < 8) {
			$("#password_error_message").html("At least 8 characters");
			$("#password_error_message").show();
			error_password = true;
		} else {
			$("#password_error_message").hide();
		}
	
	}

});

// Empty Validation
$(document).on(
		"click",
		"#submit",
		function() {

			var firstname = $("#firstname").val();
			var lastname = $("#lastname").val();
			var email = $("#email").val();
			var age = $("#age").val();
			var password = $("#password").val();
//			var cmp_email = $("#cmp_email").val();
//			var cmp_phnumber = $("#cmp_phnumber").val();

			if (firstname == "" || lastname == "" || email == ""
					|| age == "" || password == "") {

				alert("All the fields must be filled out!");
				return false;
			}

//			chk_website();
			chk_email();
//			chk_phnumber();

			if (chk_password() == false && chk_email() == false
					&& chk_phnumber() == false) {
				return false;
			}
		});