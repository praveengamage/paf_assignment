$(function() {

	$("#email_error_message").hide();
	$("#age_error_message").hide();
	$("#password_error_message").hide();

	var error_email = false;
	var error_age = false;
	var error_password = false;

	$("#form_email").focusout(function() {

		check_email();

	});

	/*
	 * $("#firstname").focusout(function() { alert("test"); })
	 */

	$("#form_age").focusout(function() {

		check_age();

	});

	$("#form_password").focusout(function() {

		check_password();

	});

	function check_email() {

		var pattern = new RegExp(
				/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);

		if (pattern.test($("#form_email").val())) {
			$("#email_error_message").hide();
		} else {
			$("#email_error_message").html("Invalid email address");
			$("#email_error_message").show();
			error_email = true;
		}

	}

	/*
	 * function check_email() {
	 * 
	 * var email_pat = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
	 * var email_val = $("#form_email").val();
	 * 
	 * if (email_pat.test(email_val) !== true) {
	 * 
	 * $("#email_error_message").html("Invalid Email!!");
	 * $("#email_error_message").show(); error_message = true;
	 *  } else {
	 * 
	 * $("#email_error_message").hide(); } }
	 */

	function check_age() {

		var age_between = $("#form_age").val();

		if (age_between < 16 || age_between > 99) {
			$("#age_error_message").html("Should be between 16-99");
			$("#age_error_message").show();
			error_age = true;
		} else {
			$("#age_error_message").hide();
		}

	}

	function check_password() {

		var password_length = $("#form_password").val().length;

		if (password_length < 8) {
			$("#password_error_message").html("At least 8 characters");
			$("#password_error_message").show();
			error_password = true;
		} else {
			$("#password_error_message").hide();
		}

	}

	$("#register_form").submit(
			function() {

				var firstname = $("#form_firstname").val();
				var lastname = $("#form_lastname").val();
				var email = $("#form_email").val();
				var age = $("#form_age").val();
				var password = $("#form_password").val();

				if (firstname == "" || lastname == "" || email == ""
						|| age == "" || password == "") {

					alert("All the fields must be filled out!");
					return false;
				}

				error_email = false;
				error_age = false;
				error_password = false;

				check_email();
				check_age();
				check_password();

				if (error_email == false && error_age == false
						&& error_password == false) {
					alert("Customer Registered Successfully!!");
					return true;
				} else {
					alert("You need to give correct details!!");
					return false;
				}

			});

	// update form(empty check and error check)
	$("#update_form").submit(
			function() {

				var firstname = $("#form_firstname").val();
				var lastname = $("#form_lastname").val();
				var email = $("#form_email").val();
				var age = $("#form_age").val();
				var password = $("#form_password").val();

				if (firstname == "" || lastname == "" || email == ""
						|| age == "" || password == "") {

					alert("All the fields must be filled out!");
					return false;
				}

				error_email = false;
				error_age = false;
				error_password = false;

				check_email();
				check_age();
				check_password();

				if (error_email == false && error_age == false
						&& error_password == false) {
					alert("Customer Updated Successfully!!");
					return true;
				} else {
					alert("You need to give correct details!!");
					return false;
				}

			});

	/*
	 * $("#deletebtn").click(function() {
	 * 
	 * alert("Do you really want to delete this supplier?"); return true; });
	 */

});

// delete button confirmation
$(document).on("click", "#delete", function() {

	if (confirm("Prompt Delete the Customer?")) {
		return true;
	} else {
		return false;
	}

});